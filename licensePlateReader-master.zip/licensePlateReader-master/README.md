# licensePlateReader
Simple Python Project using OpenCV to detect and read License Plate
